<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* themes/custom/edl_replica/templates/page.html.twig */
class __TwigTemplate_b7c655a1d85236e8d02d68a0c9792a02 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield "

<div class=\"asu-utility\">
  <div class=\"edl-container asu-utility__inner\">
    <a href=\"https://www.asu.edu\">ASU Home</a>
    <a href=\"https://my.asu.edu\">My ASU</a>
    <a href=\"https://www.asu.edu/academics/colleges-and-schools\">Colleges and Schools</a>
    <a href=\"#\">Sign In</a>
    <a href=\"#\" aria-label=\"Search ASU\">Search</a>
  </div>
</div>

<header class=\"edl-site-header\">
  <div class=\"edl-container edl-site-header__brand\">
    <a class=\"edl-asu-logo\" href=\"/\">
      <img src=\"/sites/default/files/edl-homepage/asu-logo-vertical.jpg\" alt=\"Arizona State University\">
    </a>
    <a class=\"edl-site-title\" href=\"/\">EdPlus Digital Learning</a>
  </div>
  <nav class=\"edl-main-nav\" aria-label=\"Main navigation\">
    <div class=\"edl-container edl-main-nav__inner\">
      <a href=\"/\">Home</a>
      <a href=\"#\">Our service areas</a>
      <a href=\"#\">Academic Media studios</a>
      <a href=\"#\">Course Design</a>
      <a href=\"#\">Digital Learning Platform</a>
      <a href=\"/resources\">Resources</a>
      <a href=\"#\">Contact</a>
    </div>
  </nav>
</header>

<main id=\"main-content\">
  ";
        // line 34
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["page"] ?? null), "content", [], "any", false, false, true, 34), "html", null, true);
        yield "
</main>

<footer class=\"edl-footer\">
  <div class=\"edl-container\">
    <div class=\"edl-footer__logo-row\">
      <img src=\"/sites/default/files/edl-homepage/asu-footer-logo.png\" alt=\"ASU Online\">
    </div>
    <div class=\"edl-footer__divider\" aria-hidden=\"true\"></div>
    <div class=\"edl-footer__columns\">
      <div class=\"edl-footer__brand\">
      <p>EdPlus Digital Learning</p>
      </div>
      <div>
        <h2>Our service areas</h2>
        <a href=\"#\">Instructional Design</a>
        <a href=\"#\">Academic Media</a>
        <a href=\"#\">Quality Assurance</a>
        <a href=\"/learning-technologies\">Learning Technologies</a>
        <a href=\"#\">Professional development and training</a>
      </div>
      <div>
        <h2>Other resources</h2>
        <a href=\"#\">Studios</a>
        <a href=\"#\">Digital Learning Platform</a>
        <a href=\"/resources\">Resources</a>
        <a href=\"#\">Contact us</a>
      </div>
      <div>
        <h2>Partner sites</h2>
        <a href=\"https://asu.edu\">asu.edu</a>
        <a href=\"https://asuonline.asu.edu\">ASU Online</a>
        <a href=\"https://edplus.asu.edu\">EdPlus</a>
        <a href=\"https://teachonline.asu.edu\">Teach Online</a>
      </div>
    </div>
  </div>
  <div class=\"edl-footer__innovation\">
    <div class=\"edl-container edl-footer__innovation-inner\">
      <nav class=\"edl-footer__utility\" aria-label=\"ASU utility links\">
        <a href=\"#\">Maps and Locations</a>
        <a href=\"#\">Jobs</a>
        <a href=\"#\">Directory</a>
        <a href=\"#\">Contact ASU</a>
        <a href=\"#\">My ASU</a>
      </nav>
      <img src=\"/sites/default/files/edl-homepage/footer-rank.png\" alt=\"Number one in the U.S. for innovation\">
    </div>
  </div>
  <div class=\"edl-footer__legal\">
    <div class=\"edl-container edl-footer__legal-inner\">
      <a href=\"#\">Copyright and Trademark</a>
      <a href=\"#\">Accessibility</a>
      <a href=\"#\">Privacy</a>
      <a href=\"#\">Terms of Use</a>
      <a href=\"#\">Emergency</a>
      <a href=\"#\">Manage my privacy settings</a>
    </div>
  </div>
</footer>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["page"]);        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "themes/custom/edl_replica/templates/page.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  79 => 34,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "themes/custom/edl_replica/templates/page.html.twig", "/var/www/html/web/themes/custom/edl_replica/templates/page.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = [];
        static $filters = ["escape" => 34];
        static $functions = [];

        try {
            $this->sandbox->checkSecurity(
                [],
                ['escape'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
